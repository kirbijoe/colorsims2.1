from os import path
import os
import numpy as np

################################## FOR CREATING INITIAL WCS DATA CSV FILES #####################################

########## CREATE EACH PARTICIPANT'S NAMING STRATEGY ##########

def convert_int(array):
    int_array = []
    for i in array:
        int_array.append(int(i))
    return int_array


def create_folders():
    directory = path.abspath("Single Participant Matrices")
    for i in range(1,111):
        if i != 62 and i != 93:
            folder_name = "Lang" + str(i)
            full_path = path.join(directory, folder_name)
            if not os.path.exists(full_path):
                os.makedirs(full_path)                          


def create_strategies(lang_num):
    '''lang_data is the name of a .csv file that contains the names that each
    agent assigned each chip in the color grid. Rows are each participant from
    the given language and the columns are the 320 chips.'''

    all_participants = open(path.abspath(path.join("ParticipantData", "ParticipantDataLang" + str(lang_num)+".csv")), 'r')

    line = all_participants.readline()
    participant = 1
    while line != '':
        file_name = "Lang" + str(lang_num) + "Participant" + str(participant) + ".csv"
        agent_file = open(path.abspath(path.join("Single Participant Matrices", "Lang" + str(lang_num), file_name)), 'w')
        
        line = line.replace('\n', '')
        chip_names = convert_int(line.split(','))
        agent_strategy = np.zeros((max(chip_names), 320), dtype=np.int)
        
        for chip_num in range(len(chip_names)):
            agent_strategy[int(chip_names[chip_num])-1, chip_num] = 1

        for row in agent_strategy:
            for column in range(len(row)):
                if column == (len(row) - 1):
                    agent_file.write(str(row[column]))
                else:
                    agent_file.write(str(row[column]) + ',')
            agent_file.write('\n')
        
        agent_file.close()
        line = all_participants.readline()
        participant = participant + 1

    all_participants.close()


def create_all():
    create_folders()
    
    for i in range(1,111):
        if i != 62 and i != 93:
            create_strategies(i)



########## NORMALIZE NUMBER OF NAMES IN EACH PARTICIPANT'S NAMING STRATEGY ##########

def read_csv(csv_file):
    read_file = open(csv_file, 'r')
    matrix = []
    line = read_file.readline()
    while line != '':
        line = line.strip()
        row = line.split(',')
        if row[-1] == "":
            row = row[0:-1]
        matrix.append(row)

        line = read_file.readline()

    read_file.close()
    return np.array(matrix)


def normalize_names(lang_num):
    matrix = read_csv(path.abspath(path.join("ParticipantData", "ParticipantDataLang" + str(lang_num) + ".csv")))                 
    matrix = matrix.astype(int)
    num_words = int(max(matrix.flatten()))

    directory = path.abspath(path.join("Single Participant Matrices", "Lang" + str(lang_num)))
        
    for participant in range(len(matrix)):
        participant = participant + 1
        file_path = path.join(directory, "Lang" + str(lang_num) + "Participant" + str(participant) + ".csv")
        agent_matrix = read_csv(file_path)
        agent_file = open(file_path, 'a')
        if agent_matrix.shape[0] != num_words:
            for i in range(num_words - agent_matrix.shape[0]):
                for j in range(319):
                    agent_file.write('0,')
                agent_file.write('0\n')
        agent_file.close()
        
    
def normalize_all():
    for i in range(1,111):
        if i != 62 and i != 93:
            normalize_names(i)










################################## FOR CREATING END POINT CSV FILES #####################################
#test_langs = [14,36,48,77,104,105,23,32,61,66,74,102,12,22,30,82,87,89,99]
#for i in test_langs:
#	system_soln = read_csv(path.abspath(path.join("EndParticipantData", "just in case", "system_solution_"+str(i)+".csv")))
#	system_soln = np.add(system_soln, np.ones(shape=np.shape(system_soln)))
#	write_file = open(path.abspath(path.join("EndParticipantData", "system_solution_"+str(i)+".csv")), 'w')
#	for row in range(np.shape(system_soln)[0]):
#		for col in range(np.shape(system_soln)[1]):
#			if col == np.shape(system_soln)[1] - 1:
#				write_file.write(str(system_soln[row, col]) + "\n")
#			else:
#				write_file.write(str(system_soln[row, col]) + ",")
#	write_file.close()
	

def create_folders_end(folder_num):
    directory = path.abspath(path.join("End Single Participant Matrices", str(folder_num)))
    for i in range(1,111):
        if i != 62 and i != 93:
		    folder_name = "Lang" + str(i)
		    full_path = path.join(directory, folder_name)
		    if not os.path.exists(full_path):
			    os.makedirs(full_path)                          


def create_strategies_end(lang_num, folder_num):
    '''lang_data is the name of a .csv file that contains the names that each
    agent assigned each chip in the color grid. Rows are each participant from
    the given language and the columns are the 320 chips.'''

    all_participants = open(path.abspath(path.join("EndParticipantData", str(folder_num), "system_solution_" + str(lang_num)+".csv")), 'r')

    line = all_participants.readline()
    participant = 1
    while line != '':
        file_name = "Lang" + str(lang_num) + "Participant" + str(participant) + ".csv"
        agent_file = open(path.abspath(path.join("End Single Participant Matrices", str(folder_num), "Lang" + str(lang_num), file_name)), 'w')
        
        line = line.replace('\n', '')
        line_contents = line.split(',')
        if line_contents[-1] == "":
            line_contents = line_contents[0:-1]
        chip_names = convert_int(line_contents)
        agent_strategy = np.zeros((max(chip_names)+1, 320), dtype=np.int)
        
        for chip_num in range(len(chip_names)):
            agent_strategy[int(chip_names[chip_num]), chip_num] = 1

        for row in agent_strategy:
            for column in range(len(row)):
                if column == (len(row) - 1):
                    agent_file.write(str(row[column]))
                else:
                    agent_file.write(str(row[column]) + ',')
            agent_file.write('\n')
        
        agent_file.close()
        line = all_participants.readline()
        participant = participant + 1

    all_participants.close()


def create_all_end(folder_num):
    create_folders_end(folder_num)

    for i in range(1,111):
        if i != 62 and i != 93:
		    create_strategies_end(i, folder_num)


def normalize_names_end(lang_num, folder_num):
    matrix = read_csv(path.abspath(path.join("EndParticipantData", str(folder_num), "system_solution_" + str(lang_num) + ".csv")))                 
    matrix = matrix.astype(int)
    num_words = int(max(matrix.flatten()))+1

    directory = path.abspath(path.join("End Single Participant Matrices", str(folder_num), "Lang" + str(lang_num)))
        
    for participant in range(len(matrix)):
        participant = participant + 1
        file_path = path.join(directory, "Lang" + str(lang_num) + "Participant" + str(participant) + ".csv")
        agent_matrix = read_csv(file_path)

        agent_file = open(file_path, 'a')
        if agent_matrix.shape[0] != num_words:
            for i in range(num_words - agent_matrix.shape[0]):
                for j in range(319):
                    agent_file.write('0,')
                agent_file.write('0\n')
        agent_file.close()
        
    
def normalize_all_end(folder_num):
    for i in range(1,111):
        if i != 62 and i != 93:
		    normalize_names_end(i, folder_num)



    
