from os import path
import numpy as np

#create term enumeration dictionary
term_dict = dict()
term_path = path.abspath("Folder117.7-AmericanEnglish.pdf_Unique_Response.csv")
term_file = open(term_path, 'r')
line = term_file.readline() #read out header
line = term_file.readline()
while line != "":
    contents = line.strip().split(',')
    term_dict[contents[0]] = int(contents[1])
    line = term_file.readline()
term_file.close()





def write_to_file(matrix, par_num):
    file_path = path.abspath(path.join("ColCat_AmericanEnglish", "Participant"+par_num+".csv"))
    file = open(file_path, 'w')
    line = ""
    for row in matrix:
        for cell in row:
            line += str(cell) + ','
        file.write(line[:-1]+'\n')
        line = ""
    file.close()


file_path = path.abspath("ColCat-CSV-Data-AmericanEnglish.csv")

##ids_to_skip = list(range(1,43))
##ids_to_skip.extend([83,124,165,206,247,288,329,370])
##ids_to_skip.extend(list(range(370, 411)))

file = open(file_path, 'r')

line = file.readline()  #read out header
line = file.readline()
last_informant = line.strip().split(',')[1]
strategy_matrix = np.zeros(shape=[len(term_dict),320])

while line != "":
    contents = line.strip().split(',')
    informant = contents[1]
    if informant == last_informant:
        term = term_dict[contents[4]]
        chip_id = contents[6]
        alt_id = int(contents[8])
        strategy_matrix[term-1, alt_id-1] = 1
    else:
        write_to_file(strategy_matrix, last_informant)

        last_informant = informant
        strategy_matrix = np.zeros(shape=[len(term_dict),320])
        term = term_dict[contents[4]]
        chip_id = contents[6]
        alt_id = int(contents[8])
        strategy_matrix[term-1, alt_id-1] = 1

    line = file.readline()

write_to_file(strategy_matrix, last_informant)  #write last file

file.close()








